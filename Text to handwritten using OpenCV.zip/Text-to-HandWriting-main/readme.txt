Hi This is a python project that converts text to handwriting.
This is just a prototype so it can convert only letters and certain symbols like fullstop and apostrophe

The steps for the use of the project are given below
Step1 
	Follow from step 2, if the program didnt work try installing opencv
	Install open cv, This can be done by two ways
	1.Directly using pip command in command prompt:
	 pip install opencv-python
	2.By the requirements.txt file:
	 pip install -r requirements.txt

Step2 run the file run.py

Step3 write the text you want to convert in the notepad that opens

Step4 save and close the notepad, the converted image will appear...

Note: The converted image will be stored as output.png.
      This will be overwritten when the file is run again.
      so take a backup if you wish to run the file again

And, Thats it....
Im planning to add more features in the next versions, so stay tuned

A complete video tutorial is uploaded in drive: https://drive.google.com/file/d/1oMoQgFYGJY6eU3U6FKi2rIGF6tlHIPcy/view
